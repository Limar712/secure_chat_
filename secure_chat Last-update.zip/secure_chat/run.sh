#!/bin/bash
echo "============================================"
echo "  SecureChat - Crypto UI"
echo "============================================"
echo ""
echo "Installing Flask..."
pip install flask --quiet 2>/dev/null || pip3 install flask --quiet
echo ""
echo "Starting server..."
echo ">>> Open your browser at: http://127.0.0.1:5000 <<<"
echo "Press Ctrl+C to stop"
echo ""
python app.py 2>/dev/null || python3 app.py
