@echo off
echo ============================================
echo   CryptoLab - Secure Chat Crypto UI
echo ============================================
echo.
echo Installing Flask...
pip install flask --quiet
echo.
echo Starting server...
echo Open your browser at: http://127.0.0.1:5000
echo Press Ctrl+C to stop
echo.
python app.py
pause
