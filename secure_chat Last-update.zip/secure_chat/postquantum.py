"""
postquantum.py — Post-Quantum Key Exchange Module (Bonus)

Algorithm: LWE-based Key Encapsulation (simplified Kyber-style)
Based on the Learning With Errors (LWE) hard problem.

All arithmetic is done manually using modular math — no crypto libraries.

Parameters tuned for correctness at small dimension:
  N=16, Q=97, error_bound=1 → decryption failure ~0%

Reference: Regev, O. (2009). On lattices, learning with errors, random
linear codes, and cryptography. Journal of the ACM, 56(6).
"""

import os
import hashlib

# ═══════════════════════════════════════
# PARAMETERS
# N  = polynomial degree  (use 256 for real Kyber-512)
# Q  = prime modulus      (use 3329 for real Kyber-512)
# K  = module rank        (use 2 for Kyber-512)
# EB = error bound        (keep small relative to Q/4)
# ═══════════════════════════════════════

N  = 32
Q  = 257    # prime, so Z_Q is a field; Q >> 4*EB ensures correctness
K  = 2
EB = 1      # error coefficients in {-1, 0, 1}


# ═══════════════════════════════════════
# MODULAR ARITHMETIC HELPERS
# ═══════════════════════════════════════

def _mod(x):
    return x % Q

def _poly_add(a, b):
    return [_mod(a[i] + b[i]) for i in range(N)]

def _poly_sub(a, b):
    return [_mod(a[i] - b[i]) for i in range(N)]

def _poly_mul(a, b):
    """
    Negacyclic convolution mod (x^N + 1) mod Q.
    schoolbook O(N^2) — correct for all N.
    """
    result = [0] * N
    for i in range(N):
        for j in range(N):
            idx = (i + j) % N
            sign = -1 if (i + j) >= N else 1
            result[idx] = _mod(result[idx] + sign * a[i] * b[j])
    return result

def _vec_dot(u, v):
    """Inner product of two polynomial vectors."""
    acc = [0] * N
    for i in range(len(u)):
        acc = _poly_add(acc, _poly_mul(u[i], v[i]))
    return acc

def _mat_vec(A, v):
    """Matrix-vector product where entries are polynomials."""
    return [_vec_dot(row, v) for row in A]

def _mat_transpose(A):
    return [[A[j][i] for j in range(len(A))] for i in range(len(A[0]))]


# ═══════════════════════════════════════
# SAMPLING
# ═══════════════════════════════════════

def _rand_poly():
    """Uniform polynomial in Z_Q[x]/(x^N+1)."""
    return [int.from_bytes(os.urandom(4), 'big') % Q for _ in range(N)]

def _small_poly(bound=EB):
    """
    Centered binomial B(bound): sum of (bound) pairs of random bits.
    Gives coefficients in [-bound, bound], mapped to Z_Q.
    For bound=1: coeffs in {Q-1, 0, 1}.
    """
    coeffs = []
    for _ in range(N):
        a = sum((int.from_bytes(os.urandom(1), 'big') >> i) & 1 for i in range(bound))
        b = sum((int.from_bytes(os.urandom(1), 'big') >> i) & 1 for i in range(bound))
        coeffs.append(_mod(a - b))
    return coeffs

def _rand_mat():
    return [[_rand_poly() for _ in range(K)] for _ in range(K)]

def _small_vec():
    return [_small_poly() for _ in range(K)]


# ═══════════════════════════════════════
# ENCODING / DECODING  (1 bit per coeff)
# ═══════════════════════════════════════

HALF_Q = Q // 2   # ≈ Q/2, the "1" symbol

def _encode(bits):
    """Map bit vector → polynomial: 0→0, 1→round(Q/2)."""
    return [HALF_Q * b % Q for b in bits]

def _decode(poly):
    """
    Map polynomial → bits: round each coeff to nearest multiple of Q/2.
    For each coefficient c in Z_Q, the distance to 0 is min(c, Q-c),
    and the distance to Q/2 is min(|c-Q/2|, Q-|c-Q/2|).
    """
    bits = []
    for c in poly:
        c = c % Q
        dist0    = min(c, Q - c)
        dist_half = min(abs(c - HALF_Q), Q - abs(c - HALF_Q))
        bits.append(1 if dist_half < dist0 else 0)
    return bits


# ═══════════════════════════════════════
# KEY GENERATION   (Server)
# ═══════════════════════════════════════

def lwe_keygen():
    """
    Server generates an LWE public/private keypair.

    Private key: s  (small random vector of polynomials)
    Public key:  (A, b)  where  b = A·s + e  mod Q

    Security: recovering s from (A, b) is the LWE hard problem.
    """
    A = _rand_mat()
    s = _small_vec()       # secret
    e = _small_vec()       # noise
    As = _mat_vec(A, s)
    b  = [_poly_add(As[i], e[i]) for i in range(K)]
    return {"A": A, "b": b}, {"s": s}


# ═══════════════════════════════════════
# ENCAPSULATION   (Client)
# ═══════════════════════════════════════

def lwe_encapsulate(public_key):
    """
    Client encapsulates a random N-bit shared secret using server public key.

    Produces ciphertext (u, v):
      r  ~ small random vector
      u  = A^T · r + e1
      v  = b^T · r + e2 + encode(m)

    Returns: ciphertext dict, shared_key (32 bytes)
    """
    A = public_key["A"]
    b = public_key["b"]

    m   = [int.from_bytes(os.urandom(1), 'big') % 2 for _ in range(N)]
    r   = _small_vec()
    e1  = _small_vec()
    e2  = _small_poly()

    AT  = _mat_transpose(A)
    u   = [_poly_add(_mat_vec(AT, r)[i], e1[i]) for i in range(K)]

    bTr = _vec_dot(b, r)
    v   = _poly_add(_poly_add(bTr, e2), _encode(m))

    shared_key = hashlib.sha256(bytes(m)).digest()
    return {"u": u, "v": v}, shared_key


# ═══════════════════════════════════════
# DECAPSULATION   (Server)
# ═══════════════════════════════════════

def lwe_decapsulate(ciphertext, private_key):
    """
    Server decapsulates: recover shared key using private s.

    w = v - s^T · u   ≈ encode(m) + small errors
    m'= decode(w)
    shared_key = SHA-256(m')
    """
    u = ciphertext["u"]
    v = ciphertext["v"]
    s = private_key["s"]

    sTu = _vec_dot(s, u)
    w   = _poly_sub(v, sTu)
    m_  = _decode(w)
    shared_key = hashlib.sha256(bytes(m_)).digest()
    return shared_key


# ═══════════════════════════════════════
# CONVENIENCE WRAPPERS   (for app.py)
# ═══════════════════════════════════════

def pq_handshake_server():
    """Server: generate LWE keypair. Returns (public_key, private_key)."""
    return lwe_keygen()

def pq_handshake_client(server_public_key):
    """Client: encapsulate. Returns (ciphertext, shared_key_bytes)."""
    return lwe_encapsulate(server_public_key)

def pq_handshake_server_finish(ciphertext, server_private_key):
    """Server: decapsulate. Returns shared_key_bytes."""
    return lwe_decapsulate(ciphertext, server_private_key)

def pq_keys_match(key1: bytes, key2: bytes) -> bool:
    """Constant-time comparison of two shared keys."""
    if len(key1) != len(key2):
        return False
    result = 0
    for a, b in zip(key1, key2):
        result |= a ^ b
    return result == 0
