"""
asymmetric.py — Standalone Asymmetric Encryption Module
Contains: ElGamal (key gen, encrypt, decrypt, sign, verify) — from scratch
"""

import os
import hashlib


# ═══════════════════════════════════════════════════════════════
# Miller-Rabin Primality Test
# ═══════════════════════════════════════════════════════════════

def _miller_rabin(n, k=20):
    if n < 2: return False
    if n in (2,3,5,7): return True
    if n % 2 == 0: return False
    r, d = 0, n-1
    while d % 2 == 0: r += 1; d //= 2
    for _ in range(k):
        a = 2 + int.from_bytes(os.urandom(8),'big') % (n-4)
        x = pow(a, d, n)
        if x == 1 or x == n-1: continue
        for _ in range(r-1):
            x = pow(x, 2, n)
            if x == n-1: break
        else: return False
    return True

def _random_bits(bits):
    n = int.from_bytes(os.urandom((bits+7)//8), 'big')
    n |= (1 << (bits-1)); n |= 1
    return n

def _gen_safe_prime(bits=256):
    while True:
        q = _random_bits(bits-1)
        if not _miller_rabin(q): continue
        p = 2*q+1
        if _miller_rabin(p): return p, q

def _find_generator(p, q):
    # For a safe prime p = 2q+1, any g in (1,p) with g != 1 and g != p-1
    # that satisfies g^q != 1 mod p is a generator of the subgroup of order q.
    # We try small values first for speed, then random.
    for g in range(2, 1000):
        if pow(g, q, p) != 1 and pow(g, 2, p) != 1:
            return g
    # Fallback to random search
    for _ in range(10000):
        g = 2 + int.from_bytes(os.urandom(8), 'big') % (p - 3)
        if pow(g, q, p) != 1 and pow(g, 2, p) != 1:
            return g
    # Last resort: g=2 works for most safe primes
    return 2


# ═══════════════════════════════════════════════════════════════
# ElGamal Key Generation
# ═══════════════════════════════════════════════════════════════

def generate_keys(bits=256):
    p, q = _gen_safe_prime(bits)
    g    = _find_generator(p, q)
    x    = 2 + int.from_bytes(os.urandom((bits+7)//8),'big') % (q-2)
    y    = pow(g, x, p)
    return {"p": p, "q": q, "g": g, "public_key": y, "private_key": x}


# ═══════════════════════════════════════════════════════════════
# Encrypt / Decrypt
# ═══════════════════════════════════════════════════════════════

def encrypt(m, p, g, y):
    q = (p-1)//2
    k = 2 + int.from_bytes(os.urandom((p.bit_length()+7)//8),'big') % (q-2)
    return pow(g,k,p), (m * pow(y,k,p)) % p

def decrypt(c1, c2, p, x):
    s = pow(c1, x, p)
    return (c2 * pow(s, p-2, p)) % p

def encrypt_bytes(data, p, g, y):
    m = int.from_bytes(data,'big')
    if m >= p: raise ValueError("Message too large for key size")
    return encrypt(m, p, g, y)

def decrypt_bytes(c1, c2, p, x, length):
    return decrypt(c1, c2, p, x).to_bytes(length,'big')


# ═══════════════════════════════════════════════════════════════
# Digital Signature
# ═══════════════════════════════════════════════════════════════

def _hash_msg(msg, p):
    h = hashlib.sha256(msg).digest()
    return (int.from_bytes(h,'big') % (p-1)) or 1

def _gcd(a, b):
    while b: a, b = b, a%b
    return a

def _extended_gcd(a, b):
    if a == 0: return b, 0, 1
    g, x, y = _extended_gcd(b%a, a)
    return g, y-(b//a)*x, x

def _modinv(a, m):
    g, x, _ = _extended_gcd(a, m)
    if g != 1: raise ValueError("No inverse")
    return x % m

def sign(msg, p, g, x):
    p1 = p-1
    h  = _hash_msg(msg, p)
    while True:
        k = 2 + int.from_bytes(os.urandom((p.bit_length()+7)//8),'big') % (p1-2)
        if _gcd(k, p1) != 1: continue
        r = pow(g, k, p)
        if r == 0: continue
        s = (_modinv(k, p1) * (h - x*r)) % p1
        if s == 0: continue
        return r, s

def verify(msg, r, s, p, g, y):
    if not (0 < r < p and 0 < s < p-1): return False
    h   = _hash_msg(msg, p)
    lhs = pow(g, h, p)
    rhs = (pow(y, r, p) * pow(r, s, p)) % p
    return lhs == rhs
