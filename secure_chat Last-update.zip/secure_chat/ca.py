"""
ca.py — Certificate Authority (used by server.py)
"""
import json, time
from asymmetric import generate_keys, sign, verify


class Certificate:
    def __init__(self, subject, public_key, p, g, issued_at, expires_at, serial, issuer="RootCA"):
        self.subject    = subject
        self.public_key = public_key
        self.p          = p
        self.g          = g
        self.issued_at  = issued_at
        self.expires_at = expires_at
        self.serial     = serial
        self.issuer     = issuer
        self.signature  = None

    def to_dict(self):
        return {"subject":self.subject,"public_key":self.public_key,"p":self.p,"g":self.g,
                "issued_at":self.issued_at,"expires_at":self.expires_at,
                "serial":self.serial,"issuer":self.issuer,
                "signature":list(self.signature) if self.signature else None}

    @classmethod
    def from_dict(cls, d):
        c = cls(d["subject"],d["public_key"],d["p"],d["g"],d["issued_at"],d["expires_at"],d["serial"],d["issuer"])
        if d["signature"]: c.signature = tuple(d["signature"])
        return c

    def _signable_bytes(self):
        payload = {"subject":self.subject,"public_key":self.public_key,"p":self.p,"g":self.g,
                   "issued_at":self.issued_at,"expires_at":self.expires_at,"serial":self.serial,"issuer":self.issuer}
        return json.dumps(payload, sort_keys=True).encode()

    def is_expired(self): return time.time() > self.expires_at


class CertificateAuthority:
    def __init__(self, name="RootCA", key_bits=256):
        self.name = name
        print(f"[CA] Generating {key_bits}-bit keys ...")
        keys = generate_keys(key_bits)
        self.p = keys["p"]; self.g = keys["g"]
        self.public_key = keys["public_key"]
        self._private_key = keys["private_key"]
        self._issued = {}; self._revoked = set(); self._counter = 1

    def _next_serial(self):
        s = f"{self.name}-{self._counter:06d}"; self._counter += 1; return s

    def issue_certificate(self, subject, pub_key, p, g, validity=3600):
        now = time.time()
        cert = Certificate(subject, pub_key, p, g, now, now+validity, self._next_serial(), self.name)
        cert.signature = sign(cert._signable_bytes(), self.p, self.g, self._private_key)
        self._issued[cert.serial] = cert
        print(f"[CA] Issued cert for '{subject}'")
        return cert

    def validate_certificate(self, cert):
        if cert.serial in self._revoked or cert.is_expired() or cert.issuer != self.name: return False
        r, s = cert.signature
        return verify(cert._signable_bytes(), r, s, self.p, self.g, self.public_key)

    def revoke(self, serial): self._revoked.add(serial)

    def get_public_params(self):
        return {"p":self.p,"g":self.g,"public_key":self.public_key,"name":self.name}
