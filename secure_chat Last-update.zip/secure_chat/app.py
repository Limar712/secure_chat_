"""
app.py — Flask Backend for Secure Chat System
"""

from flask import Flask, request, jsonify, send_from_directory
import os, time, statistics, hashlib

from symmetric  import xtea_encrypt, xtea_decrypt, twofish_encrypt, twofish_decrypt
from asymmetric import generate_keys, encrypt_bytes, decrypt_bytes, sign, verify
from ca         import CertificateAuthority

app = Flask(__name__, static_folder="static")

# ── CORS: allow the HTML to be opened directly as file:// too ──
@app.after_request
def add_cors(resp):
    resp.headers["Access-Control-Allow-Origin"]  = "*"
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return resp

@app.route("/api/<path:p>", methods=["OPTIONS"])
def options_handler(p):
    return "", 204

_session = {}


@app.route("/")
def index():
    return send_from_directory("static", "index.html")


# ════════════════════════════════════
# STEP 1 — Setup
# ════════════════════════════════════
@app.route("/api/setup", methods=["POST"])
def setup():
    try:
        bits = int(request.json.get("bits", 256))
        t0   = time.perf_counter()

        ca         = CertificateAuthority("SecureChatCA", key_bits=bits)
        alice_keys = generate_keys(bits)
        alice_cert = ca.issue_certificate("Alice", alice_keys["public_key"], alice_keys["p"], alice_keys["g"])
        bob_keys   = generate_keys(bits)
        bob_cert   = ca.issue_certificate("Bob",   bob_keys["public_key"],   bob_keys["p"],   bob_keys["g"])

        ms = (time.perf_counter() - t0) * 1000

        _session.update({
            "ca": ca, "alice_keys": alice_keys, "bob_keys": bob_keys,
            "alice_cert": alice_cert, "bob_cert": bob_cert,
            "enc_key": None, "xtea_key": None, "chat_log": []
        })

        return jsonify({
            "ok": True, "time_ms": round(ms, 2),
            "ca":    {"name": ca.name, "public_key": str(ca.public_key)[:80]+"...", "bits": bits},
            "alice": {"public_key": str(alice_keys["public_key"])[:80]+"...",
                      "cert_serial": alice_cert.serial,
                      "cert_valid":  ca.validate_certificate(alice_cert)},
            "bob":   {"public_key": str(bob_keys["public_key"])[:80]+"...",
                      "cert_serial": bob_cert.serial,
                      "cert_valid":  ca.validate_certificate(bob_cert)},
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ════════════════════════════════════
# STEP 2 — Key Exchange
# ════════════════════════════════════
@app.route("/api/key_exchange", methods=["POST"])
def key_exchange():
    if "ca" not in _session:
        return jsonify({"error": "Run Setup first!"}), 400
    try:
        t0 = time.perf_counter()
        bk = _session["bob_keys"]

        session_key   = os.urandom(16)
        c1, c2        = encrypt_bytes(session_key, bk["p"], bk["g"], bk["public_key"])
        bob_recovered = decrypt_bytes(c1, c2, bk["p"], bk["private_key"], 16)

        h        = hashlib.sha256(session_key).digest()
        enc_key  = h[:16]
        xtea_key = h[16:]

        _session["enc_key"]  = enc_key
        _session["xtea_key"] = xtea_key

        ms = (time.perf_counter() - t0) * 1000

        return jsonify({
            "ok": True, "time_ms": round(ms, 2),
            "session_key":  session_key.hex(),
            "keys_match":   session_key == bob_recovered,
            "c1_preview":   str(c1)[:80]+"...",
            "c2_preview":   str(c2)[:80]+"...",
            "enc_key":      enc_key.hex(),
            "xtea_key":     xtea_key.hex(),
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ════════════════════════════════════
# STEP 3 — Send Message
# ════════════════════════════════════
@app.route("/api/send_message", methods=["POST"])
def send_message():
    if not _session.get("enc_key"):
        return jsonify({"error": "Run Key Exchange first!"}), 400
    try:
        data    = request.json
        sender  = data.get("sender", "Alice")
        message = data.get("message", "").encode()
        if not message:
            return jsonify({"error": "Message is empty"}), 400

        enc_key  = _session["enc_key"]
        xtea_key = _session["xtea_key"]
        keys     = _session["alice_keys"] if sender == "Alice" else _session["bob_keys"]

        # Encrypt
        t0 = time.perf_counter()
        if len(message) <= 128:
            iv   = os.urandom(8)
            ct   = xtea_encrypt(message, xtea_key, iv)
            algo = "XTEA"
        else:
            iv   = os.urandom(16)
            ct   = twofish_encrypt(message, enc_key, iv)
            algo = "Twofish"
        enc_ms = (time.perf_counter() - t0) * 1000

        # Sign
        r, s = sign(message, keys["p"], keys["g"], keys["private_key"])

        # Decrypt
        t1 = time.perf_counter()
        decrypted = xtea_decrypt(ct, xtea_key, iv) if algo == "XTEA" else twofish_decrypt(ct, enc_key, iv)
        dec_ms = (time.perf_counter() - t1) * 1000

        sig_valid = verify(message, r, s, keys["p"], keys["g"], keys["public_key"])

        entry = {
            "sender": sender,
            "receiver": "Bob" if sender == "Alice" else "Alice",
            "plaintext":  message.decode(),
            "ciphertext": ct.hex(),
            "iv":         iv.hex(),
            "algorithm":  algo,
            "sig_valid":  sig_valid,
            "enc_ms":     round(enc_ms, 4),
            "dec_ms":     round(dec_ms, 4),
            "plain_len":  len(message),
            "ct_len":     len(ct),
            "timestamp":  time.strftime("%H:%M:%S"),
        }
        _session["chat_log"].append(entry)
        return jsonify({"ok": True, "entry": entry})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ════════════════════════════════════
# Performance
# ════════════════════════════════════
@app.route("/api/performance", methods=["GET"])
def performance():
    sizes = [64, 256, 1024, 4096]
    key16 = b"benchmarkkey1234"
    result = {"xtea": [], "twofish": []}

    for sz in sizes:
        msg = os.urandom(sz)
        iv8  = os.urandom(8); iv16 = os.urandom(16)

        te, td = [], []
        for _ in range(3):
            t0=time.perf_counter(); ct=xtea_encrypt(msg,key16,iv8);   te.append((time.perf_counter()-t0)*1000)
            t0=time.perf_counter(); xtea_decrypt(ct,key16,iv8);       td.append((time.perf_counter()-t0)*1000)
        result["xtea"].append({"size":sz,"ct_size":len(ct),"enc_ms":round(statistics.mean(te),3),"dec_ms":round(statistics.mean(td),3)})

        te, td = [], []
        for _ in range(3):
            t0=time.perf_counter(); ct=twofish_encrypt(msg,key16,iv16); te.append((time.perf_counter()-t0)*1000)
            t0=time.perf_counter(); twofish_decrypt(ct,key16,iv16);     td.append((time.perf_counter()-t0)*1000)
        result["twofish"].append({"size":sz,"ct_size":len(ct),"enc_ms":round(statistics.mean(te),3),"dec_ms":round(statistics.mean(td),3)})

    return jsonify(result)


@app.route("/api/send_file", methods=["POST"])
def send_file_msg():
    if not _session.get("enc_key"):
        return jsonify({"error": "Run Key Exchange first!"}), 400
    try:
        sender    = request.form.get("sender", "Alice")
        file_obj  = request.files.get("file")
        if not file_obj:
            return jsonify({"error": "No file provided"}), 400

        filename   = file_obj.filename
        file_bytes = file_obj.read()
        file_size  = len(file_bytes)
        mime       = file_obj.content_type or "application/octet-stream"

        xtea_key  = _session["xtea_key"]
        enc_key   = _session["enc_key"]
        keys      = _session["alice_keys"] if sender == "Alice" else _session["bob_keys"]

        # Encrypt the file bytes
        t0 = time.perf_counter()
        if file_size <= 1024 * 10:          # ≤10 KB → XTEA
            iv   = os.urandom(8)
            ct   = xtea_encrypt(file_bytes, xtea_key, iv)
            algo = "XTEA"
        else:                               # >10 KB → Twofish
            iv   = os.urandom(16)
            ct   = twofish_encrypt(file_bytes, enc_key, iv)
            algo = "Twofish"
        enc_ms = (time.perf_counter() - t0) * 1000

        # Sign the original bytes
        r, s = sign(file_bytes[:256], keys["p"], keys["g"], keys["private_key"])

        # Decrypt to verify round-trip
        t1 = time.perf_counter()
        if algo == "XTEA":
            dec = xtea_decrypt(ct, xtea_key, iv)
        else:
            dec = twofish_decrypt(ct, enc_key, iv)
        dec_ms = (time.perf_counter() - t1) * 1000

        sig_valid = verify(file_bytes[:256], r, s, keys["p"], keys["g"], keys["public_key"])

        # For images: send back base64 of decrypted so UI can preview
        import base64
        is_image  = mime.startswith("image/")
        preview   = ("data:" + mime + ";base64," + base64.b64encode(dec).decode()) if is_image else None
        file_b64  = base64.b64encode(dec).decode()

        entry = {
            "sender"    : sender,
            "receiver"  : "Bob" if sender == "Alice" else "Alice",
            "type"      : "file",
            "filename"  : filename,
            "mime"      : mime,
            "is_image"  : is_image,
            "preview"   : preview,
            "file_b64"  : file_b64,
            "algorithm" : algo,
            "sig_valid" : sig_valid,
            "enc_ms"    : round(enc_ms, 4),
            "dec_ms"    : round(dec_ms, 4),
            "plain_len" : file_size,
            "ct_len"    : len(ct),
            "timestamp" : time.strftime("%H:%M:%S"),
        }
        _session.setdefault("chat_log", []).append(entry)
        return jsonify({"ok": True, "entry": entry})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/reset", methods=["POST"])
def reset():
    _session.clear()
    return jsonify({"ok": True})


if __name__ == "__main__":
    print("Starting Secure Chat System...")
    print("Open http://127.0.0.1:5000 in your browser")
    # use_reloader=False prevents the session being wiped on code change
    app.run(debug=True, port=5000, use_reloader=False)
